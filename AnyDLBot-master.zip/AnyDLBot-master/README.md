## [AnyDLBot](https://telegram.dog/AnyDLBot)
---

An ~~Open Source~~ ALL-In-One Telegram RoBot, that can do lot of things.
👉 check the 'branches' for all the features..!

## Please use the `Releases` TAB, above to deploy this application!

## Credits, and Thanks to

* [Dan Tès](https://telegram.dog/haskell) for his [Pyrogram Library](https://github.com/pyrogram/pyrogram)
* [Yoily](https://telegram.dog/YoilyL) for his [UploaditBot](https://telegram.dog/UploaditBot)


- For FeedBack and Suggestions, please feel free to say in [@SpEcHlDe](https://telegram.dog/ThankTelegram)

#### LICENSE
- GPLv3
